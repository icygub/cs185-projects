$(function() {
  $("body").click(function() {
    location.reload();
  });
});
